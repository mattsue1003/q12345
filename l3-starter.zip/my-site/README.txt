第 3 堂練習包｜我的衛教網站
================================

這個資料夾裡有：
  index.html            虛構人物「王衛教師」的自我介紹首頁（可直接上傳練習）
  README.txt            就是這份說明

怎麼用（10 分鐘）
----------------
1. 把整個資料夾解壓縮到桌面（不要只點開 zip 裡的檔案）。
2. 雙擊 index.html，瀏覽器會打開，先看看長什麼樣。
3. 登入 github.com → 右上「＋」→ New repository
   名稱一字不差填：你的username.github.io（Public，不勾 README）。
4. 點「uploading an existing file」，把 index.html 拖進去 → Commit changes。
5. 等 1～2 分鐘，打開 https://你的username.github.io
   沒出現就到 Settings → Pages 確認 Branch 是 main、/ (root)。

改成你自己的
------------
把 index.html 整份內容貼給 ChatGPT／Claude／Gemini，說：
「請把這個網頁改成我的資料：稱呼 ○○、單位 ○○、擅長主題 ○○○，
  其他版面不要動，回傳完整的 index.html。」
存檔覆蓋後，再拖上 GitHub 一次就更新了。

接下來的實作
------------
課堂實作 1 做好的 slides.html、實作 2 做好的 mandala.html，
都丟進同一個資料夾、同一個倉庫，首頁的兩個「打開」按鈕就會通。

注意
----
- 公開網頁上不放病人資料、個人手機、住址、院內未公開文件。
- 「王衛教師」是虛構人物，只供練習；改成自己的之前請勿對外宣傳。
- 存檔時 Windows 先打開「顯示副檔名」，避免存成 index.html.txt。

講義：https://mattsue1003.github.io/q12345/lesson3.html
簡報：https://mattsue1003.github.io/q12345/lesson3-slides.html
