第 4 堂知識庫練習包

全部為課堂練習用的合成文件，內容虛構、無任何個資，可自由上傳到 ChatGPT 專案、Claude 專案或 Gemini Gem 練習。

6 份 .md 衛教文件（每份開頭有文件卡）
文件清單.xlsx：版本管理用
驗證題庫範本.xlsx：20 題三類＋評分欄＋分數紀錄

真實院內文件請先通過講義 K2 五問與院內資安同意再上傳。
講義：https://mattsue1003.github.io/q12345/lesson4.html
